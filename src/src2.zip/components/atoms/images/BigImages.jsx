import React from 'react';

const BigImages = () => {
    return (
        <div>
            
        </div>
    );
};

export default BigImages;