import React from 'react';

const LittleImages = () => {
    return (
        <div>
            
        </div>
    );
};

export default LittleImages;