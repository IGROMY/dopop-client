import React from 'react';
import styles from './Layout.module.scss'
const Layout = () => {
    return (
        <div className={styles.layout}>
        </div>
    );
};

export default Layout;